﻿
//var App = angular.module('App', ['ui.bootstrap', 'angularFileUpload', 'LocalStorageModule', 'ngSanitize', 'ui.router', 'chieffancypants.loadingBar', 'autocompleteuserrole', 'autocomplete', 'autocompleteorgcity', 'autocompletestate', 'autocompleteorgstate', 'ngMap', 'angularUtils.directives.dirPagination']);
var App = angular.module('App', ['jkuri.datepicker', 'ui.bootstrap', 'ui.router', 'ngSanitize', 'LocalStorageModule', 'chieffancypants.loadingBar', 'ngAnimate']);
