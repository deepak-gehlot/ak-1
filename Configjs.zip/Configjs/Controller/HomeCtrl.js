﻿App.controller('HomeCtrl', function ($scope, $window, localStorageService, $location) {
    $scope.showMe1 = "";
    $scope.showMe2 = "";
    $scope.showMe3 = "";
    $scope.showMe4 = "";
    $scope.showMe5 = "";
    $scope.showMe6 = "";
    $scope.showMe7 = "";
    $scope.myFunc = function (data) {
        $window.onclick = function (event) {
            $scope.showMe1 = "";
            $scope.showMe2 = "";
            $scope.showMe3 = "";
            $scope.showMe4 = "";
            $scope.showMe5 = "";
            $scope.showMe6 = "";
            $scope.showMe7 = "";
            $scope.$apply();
        };
        if (data == 1) {
            if ($scope.showMe1 == "") {
                $scope.showMe1 = "open";
            }
            else {
                $scope.showMe1 = "";

            }

            $scope.showMe2 = "";
            $scope.showMe3 = "";
            $scope.showMe4 = "";
            $scope.showMe5 = "";
            $scope.showMe6 = "";
            $scope.showMe7 = "";

        }
        if (data == 2) {
            if ($scope.showMe2 == "") {
                $scope.showMe2 = "open";
            }
            else {
                $scope.showMe2 = "";
            }
            $scope.showMe1 = "";
            $scope.showMe3 = "";
            $scope.showMe4 = "";
            $scope.showMe5 = "";
            $scope.showMe6 = "";
            $scope.showMe7 = "";
        }
        if (data == 3) {
            if ($scope.showMe3 == "") {
                $scope.showMe3 = "open";
            }
            else {
                $scope.showMe3 = "";
            }
            $scope.showMe1 = "";
            $scope.showMe2 = "";
            $scope.showMe4 = "";
            $scope.showMe5 = "";
            $scope.showMe6 = "";
            $scope.showMe7 = "";
        }
        if (data == 4) {
            if ($scope.showMe4 == "") {
                $scope.showMe4 = "open";
            }
            else {
                $scope.showMe4 = "";
            }
            $scope.showMe1 = "";
            $scope.showMe2 = "";
            $scope.showMe3 = "";
            $scope.showMe5 = "";
            $scope.showMe6 = "";
            $scope.showMe7 = "";
        }
        if (data == 5) {
            if ($scope.showMe5 == "") {
                $scope.showMe5 = "open";
            }
            else {
                $scope.showMe5 = "";
            }
            $scope.showMe1 = "";
            $scope.showMe2 = "";
            $scope.showMe3 = "";
            $scope.showMe4 = "";
            $scope.showMe6 = "";
            $scope.showMe7 = "";
        }
        if (data == 6) {
            if ($scope.showMe6 == "") {
                $scope.showMe6 = "open";
            }
            else {
                $scope.showMe6 = "";
            }
            $scope.showMe1 = "";
            $scope.showMe2 = "";
            $scope.showMe3 = "";
            $scope.showMe4 = "";
            $scope.showMe5 = "";
            $scope.showMe7 = "";
        }
        if (data == 7) {
            if ($scope.showMe7 == "") {
                $scope.showMe7 = "open";
              
            }
            else {
                $scope.showMe7 = "";
            }
            $scope.showMe1 = "";
            $scope.showMe2 = "";
            $scope.showMe3 = "";
            $scope.showMe4 = "";
            $scope.showMe5 = "";
            $scope.showMe6 = "";
           
        }

    }
    $scope.Logout = function () {
       localStorageService.set('userdetails', null);
        $location.path('Login');
    }
});