﻿App.controller('DashboardCtrl', function ($scope, $state, $location, $rootScope, RegistrationService, localStorageService) {

});
