﻿App.controller('RegistrationCtrl', function ($scope, $state,$location, $rootScope, RegistrationService, localStorageService) {

    $scope.createaccount = function (model) {
        console.log("parametes", model);
        $scope.message = '';
        RegistrationService.UserRegistration(model).success(function (data) {
            console.log("dataa", data);
         
            $scope.Model = {};
            if (data == '1') {
             
                swal('Good Job', 'Registration Successfull.', 'success');
            }
            else {
                swal('Oops...', 'unable to create', 'error');
            }
        }).error(function () {
            swal('Oops...', 'Something is not right..', 'error');
            $scope.Model = {};
        });
    }

    $scope.Logout = function () {
        localStorageService.set('userdetails', null);
        $location.path('Login');
    }

    $scope.AddContact = function (model)
    {
        RegistrationService.AddContact(model).success(function (data) {
            $scope.Model = {};
            if (data == null || data=='') {
                swal('Oops...', 'unable to create', 'error');
            }
            else {
                swal('Good Job','Contact add successfully.','success');
            }
        }).error(function () {
            swal('Oops...', 'Something is not right.', 'error');
            $scope.Model = {};
        });
    }

});

