﻿
App.controller('ContactDetailCtrl', function ($scope, $state, $location, $rootScope, $stateParams, AddContactService, localStorageService, CountryListService) {
    $scope.shownote = true;
    $scope.showtask = false;

    //--Get contact details by id
    var conid = $stateParams.ConId;
        AddContactService.GetContactDetailbyId(conid).success(function (data) {
            $scope.Model = data[0];
            console.log($scope.Model);
        }).error(function (data) {

        })


    //--Delete Contact
        $scope.DeleteContact = function (contactid,actionid)
        {
            if (actionid == 1)
            { }
            else if (actionid == 2)
            { }
            else if (actionid == 3)
            { }
            else if (actionid == 4)
            {
                AddContactService.Deletecontact(contactid).success(function (data) {
                    swal('God job.', 'Contact Deleted Successfully.', 'success');
                    $state.go('App.ViewAllContact');
                }).error(function (data){
                    swal('Ooops.', 'Something is Not Right.', 'error');
                })
            }
        }


    // --print page
        $scope.printpage = function ()
        {
            window.print();
        }


      //--save notes
        $scope.savenote = function (model)
        {
            var currentdate = new Date();
            var crntdate = currentdate.getDate();
            var crntmonth = currentdate.getMonth() + 1;
            var crntyear = currentdate.getFullYear();
            createddate = crntyear + '-' + crntmonth + '-' + crntdate;
            alert(createddate);
            var contactid = $scope.Model.ContactId;
            model.ContactId = contactid;
            model.CreatedOn = createddate;
            var data = model;
            console.log(data);
            AddContactService.savenote(data).success(function (data) {
                swal('God job', 'Note save successfully.', 'success');
                $scope.model = {};
            }).error(function (data) {
                swal('Opps..', 'Something is not right.', 'error');
                $scope.model = {};
            });
        }

    //--cleare Textbox
        //$scope.cancel = function ()
        //{
        //    $scope.model = {};
        //}

    //--Get notes details
        $scope.Getnotesdetail = function () {
            AddContactService.Getnotesdetail().success(function (data) {
                alert(data[0].CreatedOn);
                console.log(data[0]);
                //var creatdate = [];
                //alert(data.length);
                //for (var i = 0; i < data.length; i++) {
                //    var createddate = data[i].CreatedOn;
                //    var splitdate = createddate.split('T');
                //    var createdon = splitdate[2] + '/' + splitdate[1] + '/' + splitdate;
                   
                //}
                //data.CreatedOn = createdon
                //$scope.notes = data;
                console.log(data);
            }).error(function (data) {
                
            });
        }

        $scope.taskshow = function () {
            $scope.showtask = true;
            $scope.shownote =false;
        }
        $scope.noteshow = function () {
            $scope.showtask = false;
            $scope.shownote = true;
        }
});