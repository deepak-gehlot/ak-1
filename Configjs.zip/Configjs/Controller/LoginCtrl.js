﻿
App.controller('LoginCtrl', function ($scope, $state,$location, $rootScope, LoginService, localStorageService) {

    $scope.message = '';
    $scope.login = function (models)
    {
            LoginService.UserLogin(models).success(function (data) {
              localStorageService.set('userdetails', data);
              $state.go('App.Dashboard');
            //  $scope.Model = {};
        }).error(function () {
            swal('Oops..', 'Somthing is not right.', 'error');
            $scope.Model = {};
        });
    }
   
});