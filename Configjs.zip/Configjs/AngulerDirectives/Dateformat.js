﻿App.directive('validatePhone', function () {
    
    return {
        link: function (scope, elm) {
            var state = 0;

            elm.on('keydown', function (event) {
                if (event.which == 64 || event.which == 16) {
                    // to allow numbers  
                    return false;
                } else if (event.which >= 48 && event.which <= 57) {
                    // to allow numbers 

                    return true;
                } else if (event.which >= 96 && event.which <= 105) {
                    // to allow numpad number  

                    return true;
                } else if ([08, 13, 45, 27, 37, 38, 39, 40].indexOf(event.which) > -1) {
                    // to allow backspace, enter, escape, arrows  

                    return true;
                } else {
                    event.preventDefault();
                    // to stop others  
                    return false;
                }
            });
            elm.on('keydown', function (e) {

                if (e) {
                    var charCode = e.which;
                    var s = document.getElementById('CreatedDate').value;

                    var i = 0;
                    if (charCode == 08) {
                    }
                    else {
                        for (i = 0; i <= s.length - 1; i++) {
                            if (s.length == 2 && i == 1) {
                               
                                if (s > 12) {
                                    return false;
                                }
                                s = s + "/";
                               
                            }
                            if (i == 4 && s.length == 5) {
                                var d = s.split('/');
                                var dd = d[1];
                                if (dd > 31) {
                                    return false;
                                }
                                s = s + "/";

                            }
                            //if (i == 8 && s.length == 10)
                            //{
                            //    var year = s.split('/');
                            //    var yy = year[2];
                            //    if (yy < 2016)
                            //    {
                            //        return false;
                            //    }
                            //    document.getElementById("CreatedDate").value = '';
                            //}
                           
                        }
                        document.getElementById("CreatedDate").value = s;
                    }
                  
                }
                return true;
            });

        }
    }
});

