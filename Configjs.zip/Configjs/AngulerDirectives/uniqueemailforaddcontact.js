﻿App.directive('uniquemailidcon', function ($http) {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attrs, ngModel) {

            element.bind('blur', function (e) {
                var data = {
                    "EmailId": element.val()
                }
              
                $http({
                    method: "Post",
                    url: '/api/Contacts/UniqueEmailId/',
                    data: JSON.stringify(data)
                }).success(function (data) {
                  
                    if (data.length > 0) {
                        ngModel.$setValidity('uniquemailidcon', false);
                     
                        //  swal('Try Again', 'Username already in use.');
                        //alert(data.Response + 'true');
                    } else {
                        ngModel.$setValidity('uniquemailidcon', true);
                        //  alert(data.Response + 'false');
                     
                    }

                });

            });
        }
    };
})