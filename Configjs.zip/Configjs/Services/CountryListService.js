﻿App.service('CountryListService', function ($http) {
  
   
    this.GetCountryList = function () {
        var request = $http({
            method: 'Get',
            url: 'api/Countries'
            
        })
        return request;
    }
    
    this.GetstateList = function (id) {
        var request = $http({
            method: 'Get',
            url:'api/States?id=' + id

        })
        return request;
    }

    this.GetCityList = function (id) {
        var request = $http({
            method: 'Get',
            url:'api/Cities?id=' + id

        })
        return request;
    }

    this.GetAllstateList = function ()
    {
        var request = $http({
            method: 'Get',
            url:'api/States'

        })
        return request;
    }

    this.GetAllCtiyList = function ()
    {
        var request = $http({
            method: 'Get',
            url:'api/Cities'

        })
        return request;
    }
});