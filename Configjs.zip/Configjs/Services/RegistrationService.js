﻿App.service('RegistrationService', function ($http) {

    this.UserRegistration = function (model) {
        var request = $http({
            method: 'Post',
            url: 'api/Users/PostUser',
            data: model
        })
        return request;
    }

    this.AddContact = function (model) {
        var request = $http({
            method: 'Post',
            url:'api/Contacts/PostContact',
            data: model
        })
        return request;
    }
});